#!/bin/bash

. /env.sh

#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}" "${oscmd1}"
#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}"
#screen -p 0 -S mcs -X eval 'stuff "save-all"\015'
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}"
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd1}"

announce1='say 定期メッセージ'
announce2='say セーブまであと1分'
announce3='say 5'
announce4='say 4'
announce5='say 3'
announce6='say 2'
announce7='say 1'
announce7='say ご協力ありがとうございました'

${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce1}"
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce2}"
sleep 55
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce3}"
sleep 1
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce4}"
sleep 1
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce5}"
sleep 1
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce6}"
sleep 1
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce7}"
sleep 1
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "save-all"
sleep 1
${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce8}"
