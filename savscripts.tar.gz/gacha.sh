#!/bin/bash

. /env.sh

#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}" "${oscmd1}"
#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}"
#screen -p 0 -S mcs -X eval 'stuff "save-all"\015'
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}"
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd1}"


LIST='/var/spool/cron/username.list'
announce1='say ガチャ権が更新されました！'



for user in $(cat "${ULIST}"); do
        ${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "scoreboard players set ${user} Gacha_Kenri 1"
done


${MC_RCON} -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${announce1}"
