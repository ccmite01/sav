#!/bin/bash

. /env.sh

#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}"
#screen -p 0 -S mcs -X eval 'stuff "save-all"\015'
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}"

#"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}" "${sshcmd0}"
#"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd0}"

rccmde='say 定期メンテナンスによるサーバー停止まであと5分'
rccmd0='say 定期メンテナンスによるサーバー停止まであと1分'
rccmd1='say サーバー停止まであと10秒'
rccmd2='say 9'
rccmd3='say 8'
rccmd4='say 7'
rccmd5='say 6'
rccmd6='say 5'
rccmd7='say 4'
rccmd8='say 3'
rccmd9='say 2'
rccmda='say 1'
rccmdb='save-all'
rccmdc='stop'
sshcmd0="pkill java"

"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd0}"
sleep 240
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd0}"
sleep 50
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd1}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd2}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd3}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd4}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd5}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd6}"
docker update --restart=no jve
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd7}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd8}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmd9}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmda}"
sleep 1
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmdb}"
"${MC_RCON}" -H "${MC_SRVIP}" -P "${MC_RCONPORT}" -p "${MC_RCONPASS}" -s "${rccmdc}"
sleep 420
"${MC_SSH}" "${MC_USER}"@"${MC_SRVIP}" -p "${MC_SSHPORT}" "${sshcmd0}"
sleep 10
docker update --restart=no cpr
docker update --restart=no lwc
docker stop jve
docker stop cpr
docker stop lwc
